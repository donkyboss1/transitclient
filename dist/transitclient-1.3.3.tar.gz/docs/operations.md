# 🔐 Продление, восстановление и приёмка

## Сайты-заглушки

`sudo transitclient template` открывает каталог из 11 сайтов. `r` выбирает
случайный, `0` возвращает встроенную страницу, `b` откатывает прежний сайт.
Можно выбрать номер сразу: `sudo transitclient template --template 8`.
При первой установке без дополнительных вопросов выбирается случайный сайт.
Для явного выбора при установке используйте `install --template 8` или
`install --template builtin`. Подтверждение установки — `[y/N]`; Enter отменяет.

Файлы скачиваются из закреплённого upstream-коммита с проверкой размера и SHA256.
Живой сайт не очищается перед загрузкой. Проверенный сайт применяется в собственном
`site/current`, прежний сохраняется в `site/backups`. Проверяется HTTPS-ответ Caddy;
ошибка возвращает прежние файлы. Журнал смены позволяет откатиться после reboot.
Сертификат, ключ, порты и чужие сайты не меняются.

При обновлении с 1.1 прежний пользовательский сайт сохраняется. Caddy обслуживает
только активный сайт; резервные копии не публикуются. Неудача загрузки не вызывает
скрытую замену выбранного сайта встроенной страницей.

## Файлы

| Путь | Назначение |
| --- | --- |
| `/usr/local/bin/transitclient` | Собственный launcher с маркером владения |
| `/opt/tenant-selfsteal` | Runtime пакета |
| `/opt/tenant-selfsteal/.transitclient-package.json` | Маркер своего пакета и SHA256 контроллера для повторной установки после удаления |
| `/etc/tenant-selfsteal/config.json` | Root-only конфигурация 0600 |
| `/var/lib/tenant-selfsteal/acme` | Сохраняемый ACME account |
| `/var/lib/tenant-selfsteal/certs/<generation>` | Закрытые поколения cert/key |
| `/var/lib/tenant-selfsteal/certs/current` | Атомарная ссылка на действующее поколение |
| `/var/lib/tenant-selfsteal/{Caddyfile,compose.yaml,site}` | Свой Compose-проект |

Монтируется каталог certs; смена `current` видна Caddy. Ключ не пересылается.
ACME — отдельная программа, automatic HTTPS своего Caddy отключён.

## Firewall и HTTP-01

В мастере UFW управляется автоматически. Активный UFW сохраняет прежние
политики и правила. Для выключенного UFW мастер сначала показывает план:
резервная копия, постоянное разрешение TCP 22 и обнаруженных SSH/TCP/UDP-портов
работающих служб, затем включение с независимым watchdog отката.
Проверочный HTTP-порт открывается pre-hook фактического выпуска и закрывается
post-hook/watchdog/recovery. Применяется `prepend allow`: одинаковые чужие
разрешения и их комментарии сохраняются, очистка удаляет только собственный UUID.
Явный запрет/ограничение проверочного порта блокирует выпуск до ручной сверки.
Правила сохранения доступа остаются после удаления Transit Client.

Сложные правила, изменённые before/after UFW, другой firewall, неполная
инвентаризация SSH или работающие bridge-контейнеры при выключенном UFW
блокируют автоматическую активацию. Установщик не сбрасывает политики,
не меняет чужие сети и не выдаёт локальную проверку за доказанный доступ извне.
Резервные копии доступны root в `/var/lib/tenant-selfsteal/ufw-backups`; журнал
включения — `ufw-activation.json`, результат — `ufw-setup.json`.
Незавершённое включение восстанавливается через `sudo transitclient _recover`;
постоянные разрешения сохранения доступа остаются, UFW возвращается к исходному
выключенному состоянию. Watchdog включения работает независимо от установщика.

Для собственного firewall используйте `bash ./install.sh install --firewall manual`.
Если диагностика показывает `FIREWALL_FAIL2BAN_PRESENT`, обнаружены существующие
блокировки Fail2Ban (например, ipset `f2b-sshd`). Выключенный UFW не означает
отсутствия этих правил. Автоматическое включение остановлено, чтобы разрешения
UFW не обошли защиту из-за порядка цепочек. Не очищайте iptables/ipset и не
отключайте Fail2Ban ради установки. `install --firewall manual` сохраняет
существующий firewall; доступность проверочного порта через него и firewall
провайдера нужно обеспечить отдельно. Автоматическая интеграция Fail2Ban с UFW
не реализована. Правила Docker при host-контейнерах сами по себе эту ошибку
не вызывают.

В `manual` настройте firewall/NAT сами; автоматическая очистка чужих правил
не обещается. Между выпусками нет постоянного HTTP-сервиса на проверочном порту.
Только `self-test --http01` явно создаёт временный вход без ACME order.
Проверка с backend не заменяет внешнюю проверку при NAT hairpin.

## Продление и сертификат

Если официальный образ сообщает `exec /usr/bin/caddy: operation not permitted`,
проверьте ограничения контейнера: для закреплённого бинарника с
`cap_net_bind_service=ep` версия 1.3.3 сохраняет `cap_add: [NET_BIND_SERVICE]`
рядом с `cap_drop: [ALL]`. `privileged` и отключение no-new-privileges не нужны.
Изолированный запуск `caddy version` проверяется до обращения к CA.

Неудачная первая установка может оставить полученный сертификат в ACME и
поколение в certs без current. Обновление с 1.3.3 допускает это состояние,
если собственных Caddy-контейнеров нет: пакет/конфигурация проверяются без
запуска сайта и без выпуска сертификата. Затем `transitclient renew` использует
сохранённое расписание ACME и применяет имеющийся сертификат; принудительного
перевыпуска нет. При существующем контейнере без активного сертификата update
останавливается для сверки, не останавливая контейнер.

```bash
sudo transitclient status
sudo transitclient diagnose
sudo transitclient renew
sudo systemctl list-timers tenant-selfsteal-renew.timer
sudo journalctl -u tenant-selfsteal-renew.service --since today
```

Timer каждые 6 часов с jitter до 45 минут сохраняет пропущенные запуски.
acme.sh 3.1.6 учитывает ARI/своё расписание: нет допущения «90 дней», `--force`
выпуска, acme cron и auto-upgrade. До due pre-hook не вызывается.
CLI/timer используют общий lock; status/diagnose не запускают ACME/recovery.

Смена версии существующей установки выполняется через `update` с проверенным
архивом, версией и SHA256. Запуск нового внешнего пакета через `install` не
переписывает прежний runtime. Legacy VPN-порт остаётся неизвестным до явного
ввода в configure; account и работающий сертификат при обновлении сохраняются.

Для проверки target из заданного VPN-контейнера используйте
`sudo transitclient self-test --vpn`. После подтверждения выполняется только
имеющийся `openssl s_client`; пакеты и образ ноды не меняются. Если OpenSSL
или CA bundle отсутствуют, результат остаётся неподтверждённым: используйте
собственный диагностический контейнер в той же сети. STAGING trust в чужую
ноду автоматически не копируется и системное доверие не изменяется.

Перед переключением проверяются SAN, срок, trust chain и ключ. Caddy reload
использует `--force`, затем сверяется реальный TLS с SNI/h2. Ошибка возвращает
прежнее поколение/reload; при первом неудачном применении останавливается только
новый собственный Caddy. Поколения остаются backup. Сертификат на диске без
успешного применения не считается результатом.

При смене HTTP-порта сначала измените подготовку в боте, дождитесь применения,
затем `configure`. При смене HTTPS вручную обновите VPN target. Config/account
и сертификат сохраняются; configure не вызывает CA. Перед renew порт/hooks
синхронизируются в приватном domain.conf.

ACME запускается в transient systemd cgroup с 15-минутным пределом, остановкой
дочерних listener и cleanup через ExecStopPost. Renewal service имеет
20-минутный предел. До firewall-изменения сохраняется marker и запускается
25-минутный watchdog. Shell trap не единственная защита от SIGKILL.

Ошибка сохраняет прежний рабочий сертификат и безопасную причину; проверьте
status/timer, DNS, маршрут бота, firewall/NAT. После завершения аренды HTTP-маршрут
может исчезнуть и renew не пройдёт. Ранее выпущенный сертификат не отзывается.
Логи не должны содержать account/challenge/private key.

## Обновление и recovery

```bash
sudo transitclient update --package-url "$REAL_RELEASE_HTTPS_URL" \
  --version "$RELEASE_VERSION" --sha256 "$TRUSTED_RELEASE_SHA256"
```

Нужны реальный HTTPS URL, версия и доверенный SHA256 этого проекта. Latest и
upstream self-update отсутствуют. URL/хеш сохраняются после успешной проверки.
До исполнения проверяется архив: запрещены traversal, symlink/hardlink/device
и слишком большой размер. Обновление сохраняет account/config/certs/site.

Журнал/snapshot Compose/Caddy появляются до переименований. Ошибка возвращает
прежний пакет/образ; пакет остаётся `/opt/tenant-selfsteal.previous-<id>`.
Recovery с runtime helpers сохраняется отдельно в state и доступен при
временном отсутствии runtime в `/opt`. При незавершённой операции сначала
сверяйте status/журнал, затем штатный recovery:

```bash
sudo python3 /var/lib/tenant-selfsteal/recover.py _recover
```

Не удаляйте transaction markers и поколения до восстановления. Backup
account/config/key содержит секреты: храните закрыто, не добавляйте в release/Git.

## Удаление

`uninstall` показывает последствия, требует `да`, останавливает свои units/
Compose-проект и удаляет launcher/temporary rules только по владению.
Docker/system packages/VPN/чужие контейнеры/сети остаются. Config/certs/account
сохраняются root-only в `/var/lib/tenant-selfsteal-backup-<time>`, runtime
остаётся в `/opt`. Удаляйте backup вручную после проверки необходимости ключей.

## Ввод в SSH-терминале

Интерактивный запуск `curl ... | sudo bash -s -- install` может потерять
доступ к вводу терминала. Используйте команду из README: она сначала скачивает
скрипт в отдельный файл и запускает Bash с обычным терминальным stdin.
С версии 1.2.1 pipe + sudo для интерактивных операций отклоняется до установки.
Реальную совместимость конкретного sudo/SSH-клиента проверяйте отдельно.

Если старый установщик завис, в новом SSH-сеансе остановите только его процесс:

```bash
pkill -TERM -f '[p]ython3 /tmp/transitclient-bootstrap\.[^/]+/package/selfsteal\.py install([[:space:]]|$)'
pkill -CONT -f '[p]ython3 /tmp/transitclient-bootstrap\.[^/]+/package/selfsteal\.py install([[:space:]]|$)'
```

`CONT` позволяет обработать `TERM`, если процесс остановлен сигналом терминала.
Отсутствие совпадений означает, что такого процесса уже нет либо путь отличается.
Не останавливайте все Python/Docker-процессы и не удаляйте lock-файл вслепую.

## Отдельная staging-приёмка

Реальные операции и выпуск не входят в локальные тесты. Только на отдельно
разрешённом стенде, для новой установки:

```bash
sudo bash ./selfsteal.sh install \
  --staging-ca-file /secure/letsencrypt-staging-roots.pem
```

Trust bundle получите из [официальной staging-документации](https://letsencrypt.org/docs/staging-environment/).
Root-only копия остаётся в state; системный trust не меняется. STAGING помечен,
production-доверия нет. Смена CA существующей identity не автоматизирована.
Production требует отдельного разрешения и учёта
[лимитов CA](https://letsencrypt.org/docs/rate-limits/).

Внешняя матрица ещё не подтверждена: Ubuntu 22.04/24.04/26.04 amd64/arm64,
чистый сервер/существующие web servers, host/bridge VPN, IPv4/IPv6, занятый 8080,
Docker NAT без proxy, firewall/NAT, HTTP self-test, staging renewal через timer,
CA error/timeout, SIGTERM/SIGKILL/reboot, failed reload/update и сохранение
SSH/чужих ресурсов. Моки не заменяют серверную приёмку.
